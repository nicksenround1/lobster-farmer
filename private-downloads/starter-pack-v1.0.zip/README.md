# 🦞 養蝦戶 Starter Pack v1.0

> Your first step into the AI Agent world. 你的第一只龙虾。

---

## 📦 What's Inside / 包含内容

| 文件 | 说明 |
|------|------|
| `SOUL.md` | AI 人格模板 — 让你的 Agent 有灵魂 |
| `IDENTITY.md` | 身份配置 — 名字、形象、emoji |
| `USER.md` | 用户画像 — 让 Agent 理解你 |
| `HEARTBEAT.md` | 心跳任务 — 自动执行每日例行检查 |
| `AGENTS.md` | 工作指南 — Agent 的行为准则 |
| `skills/alpha-matrix/` | Alpha 信息聚合 Skill |
| `skills/daily-briefing/` | 每日简报 Skill（天气 + 新闻 + 提醒） |
| `cron-examples/` | Cron Job 模板（定时任务） |

---

## 🚀 Quick Start / 快速上手

### 方法 1: 一键安装（推荐）

```bash
curl -fsSL https://lobsterfarmer.com/install/starter-pack.sh | bash
```

这会自动：
1. 备份你现有的配置文件
2. 复制 Starter Pack 文件到你的 OpenClaw workspace
3. 安装 Skills 到正确位置

### 方法 2: 手动安装

```bash
# 1. 解压到你的 OpenClaw workspace
unzip starter-pack.zip -d ~/clawd/

# 2. 复制 Skills
cp -r skills/alpha-matrix ~/clawd/skills/
cp -r skills/daily-briefing ~/clawd/skills/

# 3. 编辑配置文件（根据你的需求自定义）
nano ~/clawd/SOUL.md
nano ~/clawd/USER.md
```

---

## 🎯 Setup Guide / 配置指南

### Step 1: 自定义人格 (SOUL.md)

打开 `SOUL.md`，修改以下部分：

```markdown
## 核心身份
你是 [你的 Agent 名字]，[你希望它成为什么角色]。
```

**提示**: 想不到？试试这些方向：
- 💼 商务助手 — "你是一个高效的商务秘书"
- 🎮 技术伙伴 — "你是一个资深程序员"
- 📊 交易顾问 — "你是一个敏锐的市场分析师"
- 🎨 创意搭档 — "你是一个天马行空的创意总监"

### Step 2: 告诉 Agent 你是谁 (USER.md)

修改 `USER.md`，让 Agent 了解你：

```markdown
# USER.md
- **Name:** 你的名字
- **Role:** 你的职业/身份
- **Preferences:** 你的偏好（语言、沟通风格等）
```

### Step 3: 设置心跳任务 (HEARTBEAT.md)

心跳是 Agent 的"自动巡逻"。每隔一段时间，它会检查清单上的项目：

```markdown
# HEARTBEAT.md
## 每次心跳检查
- 天气预报（如果你要出门）
- 未读邮件提醒
- 日历事件提醒
```

### Step 4: 启用 Cron Jobs（可选）

Cron Jobs 让 Agent 在固定时间执行任务：

```bash
# 每天早上 8:00 发送简报
openclaw cron add --name "Morning Briefing" \
  --schedule "0 8 * * *" \
  --task "运行 daily-briefing skill，给我一份今日简报"
```

参考 `cron-examples/` 目录中的模板。

---

## 📁 文件自定义说明

### SOUL.md — 人格核心
这是 Agent 的灵魂。定义：
- **身份**: 它是谁
- **性格**: 说话风格、思维方式
- **准则**: 什么该做、什么不该做
- **交互风格**: 简洁还是详细、正式还是随意

### IDENTITY.md — 外在身份
- **名字**: Agent 的名字
- **Emoji**: 它的标志性 emoji
- **Vibe**: 给人什么感觉

### HEARTBEAT.md — 自动巡逻
定义 Agent 每次心跳时该检查什么。把它想象成保安的巡逻清单。

### AGENTS.md — 行为准则
Agent 的工作手册：
- 文件管理规则
- 记忆系统说明
- 安全红线
- 群聊行为规范

---

## ❓ FAQ / 常见问题

**Q: 我需要先安装 OpenClaw 吗？**
A: 是的。请先到 https://docs.openclaw.ai 完成安装。

**Q: 这些文件会覆盖我现有的配置吗？**
A: 一键安装脚本会先备份你的现有文件。手动安装请自行备份。

**Q: Alpha Matrix Skill 需要 API key 吗？**
A: 基础版使用 web search，不需要额外 API key。高级版（Alpha Hunter Pro）需要 ReadX API。

**Q: 可以混搭其他产品的 SOUL.md 吗？**
A: 当然可以！所有产品的 SOUL.md 都可以作为模块混合使用。

**Q: 遇到问题怎么办？**
A: 加入我们的 TG 社群 https://t.me/+2p-LBUUrJ1BjMjNl，免费技术支持。

---

## 🔗 Links / 链接

- 🦞 官网: https://lobsterfarmer.com
- 💬 TG 社群: https://t.me/+2p-LBUUrJ1BjMjNl
- 🐦 Twitter: https://x.com/CKN_ACEE
- 📚 OpenClaw 文档: https://docs.openclaw.ai

---

## 📜 Changelog / 更新记录

### v1.0 (2026-02-25)
- 🎉 首次发布
- 包含 SOUL.md、IDENTITY.md、USER.md、HEARTBEAT.md、AGENTS.md
- Alpha Matrix Skill (基础版)
- Daily Briefing Skill
- Cron Job 模板

---

*Made with 🦞 by 養蝦戶 / Lobster Farmer*
*Your Agent, Your Rules.*
