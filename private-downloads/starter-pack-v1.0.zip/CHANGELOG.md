# Changelog / 更新记录

All notable changes to the 🦞 Starter Pack will be documented here.

---

## [1.0.0] — 2026-02-25

### 🎉 Initial Release
- **SOUL.md** — 通用 AI Agent 人格模板
- **IDENTITY.md** — Agent 身份配置
- **USER.md** — 用户画像模板
- **HEARTBEAT.md** — 心跳自动检查清单
- **AGENTS.md** — Agent 行为准则
- **Skills**:
  - Alpha Matrix（基础版）— Crypto 信息聚合
  - Daily Briefing — 每日自动简报
- **Cron Examples** — 6 个常用定时任务模板
- **INSTALL.md** — 完整安装指南
- **README.md** — 产品说明 + 快速上手

---

> 📢 更新通知会发到 TG 群: https://t.me/+2p-LBUUrJ1BjMjNl
> 购买用户会收到邮件更新通知
