# 🦞 養蝦戶 Starter Pack — 安装指南

## 系统要求
- macOS / Linux / Windows (WSL)
- Node.js 18+
- OpenClaw 已安装（如未安装，见下方）

---

## Step 0: 安装 OpenClaw（如果还没装）

```bash
# 安装 OpenClaw
npx openclaw@latest
```

按提示完成初始设置。详细教程：https://docs.openclaw.ai

---

## Step 1: 安装 Starter Pack

### 方法 A: 一键安装（推荐）
```bash
curl -fsSL https://lobsterfarmer.com/install/starter-pack.sh | bash
```

### 方法 B: 手动安装
```bash
# 1. 进入你的 OpenClaw workspace
cd ~/clawd  # 或你的 workspace 目录

# 2. 解压 Starter Pack
unzip ~/Downloads/starter-pack.zip -d ./

# 3. 安装 Skills
cp -r starter-pack/skills/* ./skills/

# 4. 复制配置文件（如果你还没有自定义过）
# ⚠️ 如果你已有这些文件，请手动合并而不是覆盖
cp -n starter-pack/SOUL.md ./
cp -n starter-pack/IDENTITY.md ./
cp -n starter-pack/USER.md ./
cp -n starter-pack/HEARTBEAT.md ./
cp -n starter-pack/AGENTS.md ./
```

> `-n` 参数表示不覆盖已存在的文件。

---

## Step 2: 自定义

必须修改的文件（按顺序）：

1. **USER.md** — 填入你的信息
2. **SOUL.md** — 自定义 Agent 人格
3. **IDENTITY.md** — 给 Agent 起名

可选修改：
4. **HEARTBEAT.md** — 自定义自动检查项
5. **AGENTS.md** — 调整行为规范

---

## Step 3: 验证安装

重启 OpenClaw gateway：
```bash
openclaw gateway restart
```

对 Agent 说：
```
你好！自我介绍一下
```

如果 Agent 按照你配置的 SOUL.md 回复，说明安装成功 ✅

---

## Step 4: 设置自动化（可选）

参考 `cron-examples/README.md` 设置定时任务。

推荐先设置每日简报：
```bash
openclaw cron add \
  --name "Morning Briefing" \
  --schedule "0 8 * * *" \
  --tz "你的时区" \
  --task "生成今日简报：天气、日历、新闻摘要"
```

---

## 常见问题

### "找不到 skill"
确保 skills 文件夹在你的 workspace 根目录下：
```
~/clawd/
├── skills/
│   ├── alpha-matrix/
│   │   └── SKILL.md
│   └── daily-briefing/
│       └── SKILL.md
├── SOUL.md
├── USER.md
...
```

### "Agent 没有读取 SOUL.md"
检查 AGENTS.md 是否在 workspace 根目录。Agent 启动时会按 AGENTS.md 的指示加载文件。

### "Cron Job 没有执行"
1. 确认 gateway 在运行：`openclaw gateway status`
2. 确认时区设置正确
3. 查看 cron 状态：对 Agent 说 "检查 cron job 状态"

### 需要更多帮助？
- 📚 OpenClaw 文档: https://docs.openclaw.ai
- 💬 TG 社群: https://t.me/+2p-LBUUrJ1BjMjNl
- 🐦 Twitter: https://x.com/CKN_ACEE

---

*Made with 🦞 by 養蝦戶 / Lobster Farmer*
