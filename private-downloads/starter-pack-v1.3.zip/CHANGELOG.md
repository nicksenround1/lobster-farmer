# Changelog / 更新记录

All notable changes to the 🦞 Starter Pack will be documented here.

---

## [1.3.0] — 2026-02-27

### 🆕 New Files
- **config-snippets/memory-flush.json** — 记忆刷盘预配置，context window 满时自动保存
- **config-snippets/embedding-model.json** — SiliconFlow bge-m3 向量搜索配置
- **config-snippets/README.md** — 配置片段使用说明
- **templates/daily-log-format.md** — 高质量日志格式模板（含好/差对比）
- **templates/weekly-review.md** — 每周复盘模板
- **skills/dx-terminal/SKILL.md** — DX Terminal PRO 入门指南（Base 链 AI Agent 交易市场）

### 📈 Upgraded Files
- **AGENTS.md** — 大幅升级（3x 内容密度）
  - Session 分级加载策略
  - 记忆写入规范（格式、标签、层级）
  - 安全过滤器（高危/中危关键词检测）
  - 群聊行为准则
  - 心跳主动工作建议
  - 记忆维护周期（每 3 天整理）
- **HEARTBEAT.md** — 升级
  - 轮换检查机制（不再每次全检查）
  - heartbeat-state.json 追踪
  - 主动工作建议
  - 深夜静默规则
- **cron-examples/README.md** — 升级
  - 全部改为 JSON 格式（更通用）
  - 新增：记忆维护 cron（每 3 天）
  - 新增：价格异动提醒 cron（每 4 小时）

---

## [1.0.0] — 2026-02-25

### 🎉 Initial Release
- **SOUL.md** — 通用 AI Agent 人格模板
- **IDENTITY.md** — Agent 身份配置
- **USER.md** — 用户画像模板
- **HEARTBEAT.md** — 心跳自动检查清单
- **AGENTS.md** — Agent 行为准则
- **Skills**:
  - Alpha Matrix（基础版）— Crypto 信息聚合
  - Daily Briefing — 每日自动简报
- **Cron Examples** — 6 个常用定时任务模板
- **INSTALL.md** — 完整安装指南
- **README.md** — 产品说明 + 快速上手

---

> 📢 更新通知会发到 TG 群: https://t.me/+2p-LBUUrJ1BjMjNl
> 购买用户会收到邮件更新通知
