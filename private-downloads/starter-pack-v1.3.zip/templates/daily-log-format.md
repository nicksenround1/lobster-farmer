# Daily Log Format / 每日日志模板

> 好日志 = 未来的你能 10 秒内找到需要的信息。
> A good log = your future self can find anything in 10 seconds.

---

## 标准格式

```markdown
# YYYY-MM-DD — 一句话概括今天

## HH:MM — 事件标题

### [项目名] 具体操作
- **结果**：一句话概括
- **相关文件**：`path/to/file`
- **经验教训**：要点
- **标签**：#tag1 #tag2 #tag3
```

---

## ✅ 好日志 vs ❌ 差日志

### ❌ 差日志
```markdown
今天研究了一下 DeFi，看了几个项目。晚上改了代码。
还有就是服务器出了点问题，后来修好了。
```
**问题**：没时间线、没具体信息、没法搜索、一个月后完全没用。

### ✅ 好日志
```markdown
# 2026-02-27 — 调研 Pendle + 修复 gateway 崩溃

## 09:30 — Pendle V3 研究

### [Alpha] Pendle V3 机制变化
- **结果**：新增 Flash Swap，PT 可直接兑换底层资产，无需等到期
- **相关文件**：`research/pendle-v3-notes.md`
- **经验教训**：PT 折价 > 5% 时有套利空间
- **标签**：#defi #pendle #yield #alpha

## 14:20 — Gateway 崩溃修复

### [Infra] openclaw gateway 反复重启
- **结果**：原因是 .env 里 API key 过期，更换后恢复
- **相关文件**：`~/.config/openclaw/openclaw.json`
- **经验教训**：API key 轮换时记得同步更新所有引用位置
- **标签**：#infra #bug #gateway

## 22:00 — 日终总结
- 完成 Pendle 研究，明天写交易策略
- Gateway 问题已修，运行稳定
- TODO：设置 API key 过期提醒 cron
```

---

## Tips

1. **时间戳必写** — 没有时间线的日志是流水账
2. **标签要一致** — 统一用 `#alpha` `#infra` `#trade` 等，方便搜索
3. **经验教训最重要** — 这是日志的核心价值
4. **日终总结** — 花 30 秒写明天要做什么，省明天 30 分钟
5. **不用面面俱到** — 只记有价值的事，吃了什么午饭不需要

---

*Part of 🦞 養蝦戶 Starter Pack v1.3*
