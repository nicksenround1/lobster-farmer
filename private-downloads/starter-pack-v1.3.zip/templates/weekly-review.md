# Weekly Review Template / 每周复盘模板

> 每周五花 15 分钟复盘。Agent 可以帮你自动生成初稿，你只需要补充和修正。

---

## 模板

```markdown
# Week of YYYY-MM-DD ~ YYYY-MM-DD

## 📊 本周概览 / Summary
- **关键成果**：（最重要的 1-3 件事）
- **意外收获**：（计划外但有价值的事）
- **未完成**：（拖到下周的事 + 原因）

## 💰 投资/交易回顾（可选）
| 操作 | 标的 | 结果 | 教训 |
|------|------|------|------|
| Buy  | XXX  | +12% | 入场时机不错 |

## 🧠 本周学到什么
- （新知识、新工具、新认知）

## ⚠️ 本周犯的错
- （哪里浪费时间了？哪个决策有问题？）
- （如何避免重复犯？）

## 📋 下周计划
- [ ] 任务 1 — 优先级/截止日期
- [ ] 任务 2
- [ ] 任务 3

## 🔧 Agent/工具优化
- （这周发现 Agent 哪里不好用？要改什么配置？）
- （新增了什么 Skill/Cron？效果如何？）
```

---

## 自动化建议

用 Cron Job 让 Agent 每周五自动生成初稿：

```json
{
  "name": "Weekly Review Draft",
  "schedule": "0 17 * * 5",
  "tz": "你的时区",
  "task": "读取本周 memory/ 日志（周一到周五），按 templates/weekly-review.md 的格式生成周报初稿，保存到 memory/reviews/YYYY-WXX.md"
}
```

---

*Part of 🦞 養蝦戶 Starter Pack v1.3*
