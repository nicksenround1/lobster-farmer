# Cron Job Examples / 定时任务模板 v1.3

> JSON 格式，直接用 `openclaw cron add --json` 导入。
> JSON format — import with `openclaw cron add --json`.

---

## 每日早间简报

```json
{
  "name": "Morning Briefing",
  "schedule": "0 8 * * *",
  "tz": "Australia/Sydney",
  "task": "生成今日简报：天气（Sydney）、日历提醒、Crypto 价格（BTC/ETH/SOL）、重要新闻摘要",
  "timeout": 300
}
```

## 每日 Crypto 市场报告

```json
{
  "name": "Alpha Matrix Daily",
  "schedule": "0 12 * * *",
  "tz": "Australia/Sydney",
  "task": "运行 Alpha Matrix，扫描过去 24 小时 Crypto 动态，输出情报报告",
  "timeout": 1800
}
```

## 每周安全扫描

```json
{
  "name": "Weekly Security Scan",
  "schedule": "0 10 * * 1",
  "tz": "Australia/Sydney",
  "task": "执行系统安全扫描：检查防火墙、开放端口、远程控制软件、Chrome 扩展、可疑进程。输出简报。",
  "timeout": 600
}
```

## 每周复盘

```json
{
  "name": "Weekly Review",
  "schedule": "0 17 * * 5",
  "tz": "Australia/Sydney",
  "task": "读取本周 memory/ 日志，按 templates/weekly-review.md 格式生成周报初稿，保存到 memory/reviews/YYYY-WXX.md",
  "timeout": 600
}
```

## 工作日下班提醒

```json
{
  "name": "EOD Reminder",
  "schedule": "0 17 * * 1-5",
  "tz": "Australia/Sydney",
  "task": "提醒我：今天的任务完成了吗？有什么需要明天跟进的？"
}
```

## 记忆维护（每 3 天）

```json
{
  "name": "Memory Maintenance",
  "schedule": "0 10 */3 * *",
  "tz": "Australia/Sydney",
  "task": "读取近 3 天 memory/ 日志，提取重要信息更新到 MEMORY.md，清理过时内容，更新 heartbeat-state.json",
  "timeout": 600
}
```

## 价格异动提醒

```json
{
  "name": "Price Alert",
  "schedule": "0 */4 * * *",
  "tz": "Australia/Sydney",
  "task": "检查 BTC/ETH/SOL 价格。如果过去 4 小时涨跌超过 5%，立即通知。附带简短分析（可能原因）。平稳则不通知。",
  "timeout": 300
}
```

## 一次性提醒（定时闹钟）

```json
{
  "name": "Meeting Reminder",
  "schedule": "2026-03-01T13:30:00+11:00",
  "task": "提醒：30 分钟后有团队会议，准备好会议材料"
}
```

---

## Tips

- **`schedule`**: Cron 表达式 `分 时 日 月 周几`，或 ISO 时间（一次性）
- **`tz`**: 时区，不设置默认 UTC
- **`timeout`**: 超时秒数，复杂任务建议 300+
- **常用表达式**:
  - `0 8 * * *` → 每天 08:00
  - `0 12 * * 1-5` → 工作日 12:00
  - `0 10 * * 1` → 每周一 10:00
  - `0 */4 * * *` → 每 4 小时
  - `0 10 */3 * *` → 每 3 天 10:00
- 验证表达式：https://crontab.guru

---

*Part of 🦞 養蝦戶 Starter Pack v1.3*
