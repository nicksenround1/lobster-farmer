# DX Terminal PRO — 入门指南

> Base 链上 AI Agent 自主交易市场。你买 Agent NFT，给它充 ETH，它帮你交易。

---

## 什么是 DX Terminal PRO

DX Terminal 是一个 AI Agent 交易平台，运行在 Base L2 上。每个 Agent 是一个 NFT，持有者可以：
- 指导 Agent 的交易策略（通过自然语言）
- 为 Agent 充值 ETH 作为交易资金
- 质押 NFT 获取平台收益分成
- 观察 Agent 的链上操作和 PnL

**官网**：https://terminal.markets / https://dxrg.ai

## 参与流程

### Step 1: 买 Agent NFT
- **合约地址**: `0x41dc69132cce31fcbf6755c84538ca268520246f`（Base 链）
- 在 OpenSea / Blur / 官网购买
- 每个 NFT = 一个独立的 AI 交易 Agent

### Step 2: 质押 NFT
- 在 terminal.markets 连接钱包
- 质押你的 Agent NFT 到平台
- 质押后可以配置 Agent 参数

### Step 3: 充值 ETH
- 往你的 Agent 地址充入 ETH（Base 链）
- 这是 Agent 的交易本金
- 建议先小额测试（0.01-0.05 ETH）

### Step 4: 指导 Agent
- 通过平台界面给 Agent 下达策略指令
- 例如："只做 meme coin，单笔不超过 0.005 ETH"
- Agent 会在链上自主执行

## 核心信息

| 项目 | 详情 |
|------|------|
| 链 | Base (L2) |
| NFT 合约 | `0x41dc69132cce31fcbf6755c84538ca268520246f` |
| 官网 | terminal.markets / dxrg.ai |
| 代币 | 有平台代币（DXRG），具体 tokenomics 查官网 |

## ⚠️ 风险提示 / Risk Warning

1. **AI 交易有亏损风险** — Agent 不是印钞机，亏损是常态
2. **智能合约风险** — 合约未经你个人审计，使用需信任平台
3. **NFT 价格波动** — Agent NFT 本身价格可能归零
4. **小额起步** — 先用你能承受损失的金额测试
5. **DYOR** — 这是信息指南，不是投资建议

> 💡 这个 Skill 提供信息参考。自动化交易功能需要额外配置，不在本 Skill 范围内。

---

*Part of 🦞 養蝦戶 Starter Pack v1.3*
