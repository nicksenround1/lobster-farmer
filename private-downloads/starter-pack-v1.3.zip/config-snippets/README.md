# Config Snippets / 配置片段

> 直接复制进你的 `openclaw.json`，立即生效。
> Copy-paste into your `openclaw.json` — works immediately.

---

## 使用方法 / How to Use

你的 `openclaw.json` 是一个 JSON 对象。把片段的内容合并进去即可。

**例子：** 假设你的 `openclaw.json` 当前是：
```json
{
  "model": "anthropic/claude-sonnet-4-20250514",
  "channels": { ... }
}
```

要加入 `memory-flush.json`，把 `memoryFlush` 字段加进去：
```json
{
  "model": "anthropic/claude-sonnet-4-20250514",
  "channels": { ... },
  "memoryFlush": {
    "enabled": true,
    "softThresholdTokens": 4000,
    "prompt": "Context window is getting full. Before compaction, save any important information from this conversation to memory/ files. Use the format specified in AGENTS.md."
  }
}
```

同理，`embedding-model.json` 加入 `memorySearch` 字段。

---

## 片段说明

### memory-flush.json — 记忆刷盘
当 context window 快满时，Agent 会自动把重要信息保存到 `memory/` 文件。

- `softThresholdTokens`: 触发刷盘的 token 阈值（建议 3000-5000）
- `prompt`: Agent 刷盘时的指令

### embedding-model.json — 语义搜索（Embedding）
让 Agent 用向量搜索查找记忆，而不只是关键词匹配。

- 使用 SiliconFlow 的 `bge-m3` 模型（中英双语效果好）
- 需要 SiliconFlow API Key（注册免费送额度）
- 设置环境变量：`OPENCLAW_MEMORY_SEARCH_API_KEY=你的key`

> ⚠️ 没有 API Key 也能用 OpenClaw，只是记忆搜索退化为关键词匹配。

---

*Part of 🦞 養蝦戶 Starter Pack v1.3*
