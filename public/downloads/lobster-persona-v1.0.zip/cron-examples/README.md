# Cron Job Examples / 定时任务模板

> 复制粘贴即用。修改时间和内容即可。

---

## 每日早间简报
```bash
openclaw cron add \
  --name "Morning Briefing" \
  --schedule "0 8 * * *" \
  --tz "Australia/Sydney" \
  --task "生成今日简报：天气（Sydney）、日历提醒、Crypto 价格（BTC/ETH/SOL）、重要新闻摘要"
```

## 每日 Crypto 市场报告
```bash
openclaw cron add \
  --name "Alpha Matrix Daily" \
  --schedule "0 12 * * *" \
  --tz "Australia/Sydney" \
  --task "运行 Alpha Matrix，扫描过去 24 小时 Crypto 动态，输出情报报告" \
  --timeout 1800
```

## 每周安全扫描
```bash
openclaw cron add \
  --name "Weekly Security Scan" \
  --schedule "0 10 * * 1" \
  --tz "Australia/Sydney" \
  --task "执行系统安全扫描：检查防火墙、开放端口、远程控制软件、Chrome 扩展、可疑进程。输出简报。"
```

## 每周复盘
```bash
openclaw cron add \
  --name "Weekly Review" \
  --schedule "0 18 * * 5" \
  --tz "Australia/Sydney" \
  --task "读取本周的 memory/ 日志，生成周报：完成了什么、遗留什么、下周计划"
```

## 工作日下班提醒
```bash
openclaw cron add \
  --name "EOD Reminder" \
  --schedule "0 17 * * 1-5" \
  --tz "Australia/Sydney" \
  --task "提醒我：今天的任务完成了吗？有什么需要明天跟进的？"
```

## 一次性提醒（定时闹钟）
```bash
openclaw cron add \
  --name "Meeting Reminder" \
  --schedule "2026-03-01T13:30:00+11:00" \
  --task "提醒：30 分钟后有团队会议，准备好会议材料"
```

---

> 💡 **Tips**:
> - `--tz` 设置时区，不设置默认 UTC
> - `--timeout` 设置超时时间（秒），复杂任务建议 300+
> - Cron 表达式格式: `分 时 日 月 周几`
>   - `0 8 * * *` = 每天 8:00
>   - `0 12 * * 1-5` = 工作日 12:00
>   - `0 10 * * 1` = 每周一 10:00
> - 用 https://crontab.guru 验证你的表达式

---

*Part of 🦞 養蝦戶 Starter Pack*
