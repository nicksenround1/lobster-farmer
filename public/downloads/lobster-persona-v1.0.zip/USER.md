# USER.md — 用户画像

> 告诉你的 Agent 你是谁，它才能更好地为你服务。

- **Name:** [你的名字]
- **Role:** [你的身份/职业]
- **Language:** [中文 / English / 双语]
- **Profile:**
  - [描述你自己，让 Agent 了解你的背景]
  - [你的兴趣、工作领域]
  - [你希望 Agent 怎么帮你]
- **Security Clearance:** Level 5 (Owner)

## 偏好
- [你喜欢什么沟通风格？简洁？详细？]
- [有什么特别的需求？]
- [时区？工作时间？]

---

> 💡 **示例**:
> ```
> - Name: Alex
> - Role: 全栈开发者 / Crypto 交易员
> - Language: 中英双语
> - Profile:
>   - 白天写代码，晚上看 K 线
>   - 需要帮忙管理 GitHub PR 和监控链上 Alpha
> - 偏好：不要废话，直接给方案
> ```
