# 🦞 养虾户 Persona 包 — Lobster Farmer Persona Package

> **"Your AI co-pilot for Crypto Alpha, built for the Chinese-speaking Web3 community."**

---

## 📦 包含什么

```
persona-package/
├── README.md              ← 你正在看的文件
├── SOUL.md                ← Agent 人格模板（可自定义）
├── setup-guide.md         ← 从零配置完整指南
├── USER-template.md       ← 用户信息模板
├── IDENTITY-template.md   ← Agent 身份模板
├── HEARTBEAT-template.md  ← 心跳任务模板
├── AGENTS-additions.md    ← 推荐添加到 AGENTS.md 的内容
└── examples/
    ├── soul-crypto-trader.md    ← SOUL 示例：Crypto Trader
    ├── soul-developer.md        ← SOUL 示例：独立开发者
    └── soul-researcher.md       ← SOUL 示例：研究员
```

---

## 🎯 这个包能帮你做什么

1. **快速上手** —— 不用从零写 SOUL.md，有模板和三种预设人格
2. **Crypto 优化** —— 内置链上操作安全规则、Alpha 情报工作流、OpSec 最佳实践
3. **中文优先** —— 所有模板都是中文，但支持中英双语
4. **安全第一** —— 内置 prompt injection 防御、钱包操作确认机制、敏感信息过滤器

---

## 🆚 和别人的 Persona 包有什么不同？

| 特性 | 养虾户 | Felix ($99) | Brian Wagner ($19) |
|------|--------|------------|-------------------|
| 语言 | 中文优先 | 英文 | 英文 |
| Crypto/Web3 | ✅ 深度集成 | ❌ | ❌ |
| Alpha 情报 | ✅ ReadX + Alpha Matrix | ❌ | ❌ |
| 链上操作安全 | ✅ 详细规则 | ❌ | ❌ |
| 记忆系统 | ✅ 优化配置 | ✅ 三层架构 | ⚠️ 基础 |
| 可自定义 | ✅ 模板 + 示例 | ⚠️ 固定人设 | ⚠️ 有限 |
| 价格 | $49 | $99 | $19 |

---

## 🚀 快速开始

1. 阅读 `setup-guide.md` 完整配置指南
2. 从三个示例中选一个最接近你的，复制为你的 `SOUL.md`
3. 填写 `USER-template.md` 和 `IDENTITY-template.md`
4. 把 `HEARTBEAT-template.md` 复制到你的 workspace
5. 开始和你的龙虾对话！

---

## ⚠️ 注意事项

- 本包**不包含** API keys。你需要自己获取 Anthropic/Bankr/ReadX 的 key。
- 本包**不包含** OpenClaw 软件本身。请先安装 OpenClaw (`openclaw.ai`)。
- 所有 Crypto 相关内容 **NFA/DYOR** —— 不构成投资建议。

---

## 📞 支持

- Telegram 群：🦞养虾户和他的朋友们
- 问题反馈：在 Claw Mart 评论区留言

---

*Made by 养虾户 (Lobster Farmer) 🦞*
*基于 OpenClaw v2026.2.x*
