# HEARTBEAT.md

## 1. Open Projects 监控（最高优先级）
检查 `memory/YYYY-MM-DD.md`（今天）中是否有标记为 `[ACTIVE]` 的任务或 sub-agent session。
- 如果有 active session：用 `subagents list` 检查状态
  - 还在跑 → 不做任何事
  - 挂了/失败 → 自动重启，不用通知 Ace
  - 完成了 → 通知 Ace 结果 + 链接
- 如果 daily note 里记录了未完成任务但没有对应 session → 提醒 Ace 或自动恢复

## 2. Alpha Matrix Scheduler
如果当前时间在 12:00-12:59 (Sydney Time)，且今天尚未运行，执行 "Run Alpha Matrix"。
运行完毕后，同时发送一份到 TG 群 (-1003683464444)。

## 3. 轮换检查（每次 heartbeat 选 1-2 个，别全做）
参考 `memory/heartbeat-state.json` 上次检查时间，优先检查最久没查的：
- **Weather** — 如果 Ace 可能出门（工作日早上/下午）
- **Memory Maintenance** — 每 3 天检查一次，整理 daily notes → MEMORY.md

## 规则
- 深夜 23:00-08:00 除非有 urgent active task，否则 HEARTBEAT_OK
- 没什么事就回 HEARTBEAT_OK，别废话
- 发现 active task 完成/失败才通知
