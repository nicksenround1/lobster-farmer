# Alpha Matrix — 信息聚合 Skill

> 多源信息聚合，帮你快速掌握 Crypto / Tech / 市场动态。

## 功能
- 聚合多个信息源（Twitter KOL、新闻、链上数据）
- 生成结构化情报报告
- 支持 Cron 定时自动运行

## 使用方法

### 手动触发
直接对 Agent 说：
```
运行 Alpha Matrix，给我一份今日 Crypto 情报
```

### 自动定时（推荐）
设置 Cron Job，每天中午自动运行：
```bash
openclaw cron add \
  --name "Daily Alpha Matrix" \
  --schedule "0 12 * * *" \
  --task "运行 Alpha Matrix，扫描最近 24 小时的 Crypto 动态，生成情报报告发给我" \
  --timeout 1800
```

## 信息源
基础版使用 web search 抓取以下类型的信息：
- 📰 Crypto 新闻（CoinDesk, The Block, Decrypt）
- 🐦 KOL 观点（通过公开 timeline）
- 📊 市场数据（价格、涨跌幅、成交量）
- 🔗 链上活动（大额转账、新项目）

## 报告格式
```
## 🦞 Alpha Matrix Daily Report — YYYY-MM-DD

### 🔥 Today's Alpha
1. [最重要的信息]
2. [第二重要的信息]
...

### 📊 Market Overview
- BTC: $XX,XXX (±X.X%)
- ETH: $X,XXX (±X.X%)
- Total Market Cap: $X.XT

### 🐦 KOL Highlights
- @xxx: "..."
- @yyy: "..."

### 💡 Opportunities
- [值得关注的机会]

### ⚠️ Risks
- [需要警惕的风险]
```

## 升级到 Pro 版
基础版只使用公开信息。升级到 **Alpha Hunter Pro** ($29) 可获得：
- ReadX API 集成 — 直接读取 KOL 完整 timeline
- Whale Alert 监控
- 新币上线提醒
- 情绪分析面板

👉 https://lobsterfarmer.com/products/alpha-hunter-pro

---

*Part of 🦞 養蝦戶 Starter Pack*
