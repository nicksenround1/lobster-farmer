# Daily Briefing — 每日简报 Skill

> 每天早上自动生成一份简报，让你 30 秒内了解今天需要知道的一切。

## 功能
- 🌤️ 今日天气 + 穿衣建议
- 📅 今日日程提醒
- 📰 新闻摘要（可配置关注领域）
- 💰 Crypto 价格速览（可选）
- ✅ 待办事项提醒

## 使用方法

### 手动触发
```
给我一份今日简报
```

### 自动定时（推荐）
每天早上 8:00 自动发送：
```bash
openclaw cron add \
  --name "Morning Briefing" \
  --schedule "0 8 * * *" \
  --task "运行 Daily Briefing，生成今日简报。包含天气（[你的城市]）、日历、新闻和 crypto 价格" \
  --timeout 300
```

## 配置

在 Cron 任务的 task 中指定你的偏好：

```
# 城市（天气用）
城市: Sydney

# 关注领域（新闻用）
领域: Crypto, AI, Tech

# 是否包含 Crypto 价格
Crypto: 是

# 关注的代币
代币: BTC, ETH, SOL
```

## 简报格式
```
☀️ 早安！这是你的今日简报 — 2026-02-25

🌤️ 天气: Sydney 22°C，晴转多云，下午可能有雨，带伞
📅 日程: 
  - 14:00 团队会议
  - 18:00 健身
📰 新闻:
  - [AI] OpenAI 发布新模型...
  - [Crypto] BTC 突破 $70K...
💰 Crypto:
  - BTC $70,123 (+2.3%)
  - ETH $3,456 (+1.8%)
  - SOL $123 (-0.5%)
✅ 待办:
  - 完成项目报告
  - 回复客户邮件
```

## 依赖
- Weather: 使用 wttr.in（免费，无需 API key）
- Calendar: 读取系统日历或 HEARTBEAT.md 中的日程
- News: 使用 web_search（免费）
- Crypto: 使用公开价格 API（免费）

## 小技巧
- 把 Daily Briefing 和 HEARTBEAT.md 结合使用
- 周末可以设置不同的简报内容（少点工作，多点生活）
- 搭配 TTS skill 可以让 Agent 用语音读给你听

---

*Part of 🦞 養蝦戶 Starter Pack*
