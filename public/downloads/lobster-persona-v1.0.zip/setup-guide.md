# 🦞 养虾户 Persona 包 — 配置指南

> **预计时间: 20-30 分钟** | **前提: 已安装 OpenClaw 并能对话**

---

## Step 0: 前置条件

确认以下条件已满足：

- [ ] OpenClaw 已安装并正常运行 (`openclaw gateway status`)
- [ ] 至少一个 channel 已连接（Telegram/Discord）
- [ ] AI Model 已配置（推荐 Anthropic Claude）
- [ ] 能和 Agent 正常对话

如果还没安装 OpenClaw，请先阅读《养虾户指南》第三章，或访问 [openclaw.ai](https://openclaw.ai)。

---

## Step 1: 备份现有配置

**在做任何改动之前，先备份！**

```bash
# 找到你的 workspace 目录
# 默认: ~/.openclaw/workspace/ 或你自定义的路径

cd YOUR_WORKSPACE_DIR

# 备份现有文件
mkdir -p backups/$(date +%Y%m%d)
cp SOUL.md AGENTS.md USER.md IDENTITY.md backups/$(date +%Y%m%d)/ 2>/dev/null
echo "备份完成: backups/$(date +%Y%m%d)/"
```

---

## Step 2: 安装 SOUL.md

### 方案 A: 使用通用模板
```bash
# 复制模板
cp persona-package/SOUL.md YOUR_WORKSPACE_DIR/SOUL.md
```

### 方案 B: 使用预设人格
```bash
# Crypto Trader 人格
cp persona-package/examples/soul-crypto-trader.md YOUR_WORKSPACE_DIR/SOUL.md

# 独立开发者人格
cp persona-package/examples/soul-developer.md YOUR_WORKSPACE_DIR/SOUL.md

# 研究员人格
cp persona-package/examples/soul-researcher.md YOUR_WORKSPACE_DIR/SOUL.md
```

### 自定义
打开 `SOUL.md`，搜索 `[自定义]` 标记，根据你的需要修改：
- 交易确认阈值（默认 0.5 ETH）
- 每日累计限额（默认 2 ETH）
- 活跃时间段（默认 08:00-23:00）
- 语言偏好
- 详细程度

---

## Step 3: 配置用户信息

```bash
cp persona-package/USER-template.md YOUR_WORKSPACE_DIR/USER.md
```

编辑 `USER.md`，填写你的信息：
- 名字/昵称
- 角色/职业
- 时区
- 语言偏好
- 关注的赛道/项目

---

## Step 4: 配置 Agent 身份

```bash
cp persona-package/IDENTITY-template.md YOUR_WORKSPACE_DIR/IDENTITY.md
```

给你的 Agent 起个名字！有名字的 Agent 回复更有人味。

---

## Step 5: 配置心跳任务

```bash
cp persona-package/HEARTBEAT-template.md YOUR_WORKSPACE_DIR/HEARTBEAT.md
```

心跳是 Agent 定期"醒来"检查事情的机制。模板已包含：
- 活跃任务监控
- Alpha Matrix 定时触发
- 轮换检查（天气、记忆整理）

根据需要调整时间和频率。

---

## Step 6: Crypto 工具配置（可选但推荐）

### 6.1 Bankr 钱包
```bash
# 安装 Bankr CLI
bun install -g @bankr/cli
# 或 npm install -g @bankr/cli

# 注册
bankr login email your@email.com

# 输入验证码
bankr login email your@email.com \
  --code 123456 \
  --accept-terms \
  --key-name "My Lobster" \
  --read-write

# 记录 API Key
echo 'export BANKR_API_KEY="bk_..."' >> ~/.zshrc
source ~/.zshrc
```

### 6.2 ReadX (Twitter 情报)
```bash
# 注册获取 API key: https://readx.cc
mkdir -p ~/.config/readx
echo '{"api_key":"YOUR_KEY"}' > ~/.config/readx/credentials.json
```

⚠️ **安全提醒**: 
- Bankr 钱包只放小额资金
- API keys 不要放在 workspace 文件里
- 不要在聊天中发送 API keys

---

## Step 7: 验证

重启 Gateway（或等下一次对话自动加载）：

```bash
openclaw gateway restart
```

然后在 Telegram/Discord 中测试：

```
你: "你是谁？介绍一下你自己。"
→ Agent 应该按照新 SOUL.md 的人格回复

你: "帮我查一下 BTC 的价格"
→ 如果配了 Bankr，应该能查到

你: "帮我分析 @VitalikButerin 最近的推文"
→ 如果配了 ReadX，应该能分析
```

---

## Step 8: 微调

**SOUL.md 不是一劳永逸的**。用几天之后你会发现：
- 某些回复太长 → 在 SOUL.md 里加字数限制
- 安全确认太频繁 → 调高阈值
- 语气不对 → 修改性格描述

直接编辑 SOUL.md，下次对话自动生效。

你也可以让 Agent 自己改：
```
你: "你之后回复不要超过 200 字，把这个规则加到 SOUL.md 里"
```

---

## 常见问题

**Q: 改了 SOUL.md 但 Agent 没变？**
A: 确认你改的是 Agent 实际加载的那个文件。运行 `openclaw gateway status` 查看 workspace 路径。

**Q: Agent 拒绝执行交易？**
A: 检查 SOUL.md 中的安全规则。如果阈值太低，Agent 会要求确认。说 "确认" 即可。

**Q: 群聊中 Agent 太活跃？**
A: 在 SOUL.md 的群聊行为部分，加上 "只在被 @ 时回复" 规则。

**Q: 想恢复默认？**
A: 从 Step 1 的备份恢复：
```bash
cp backups/YYYYMMDD/SOUL.md YOUR_WORKSPACE_DIR/SOUL.md
```

---

*需要帮助？加入 🦞养虾户和他的朋友们 Telegram 群*
